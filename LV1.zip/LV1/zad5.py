file = open("song.txt")
